<?php

/*
    controlador: index.php
    descripción: Controlador principal del proyecto CRUD de artículos POO
*/

// incluir las clases necesarias
require_once 'class/articulo.class.php';
require_once 'class/tabla_articulos.class.php';

// incluir el modelo
require_once 'models/index.model.php';

// incluir la vista
require_once 'views/index.view.php';
?>