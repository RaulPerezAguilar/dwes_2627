<?php

/*
    controlador: create.php
    descripción: añade un nuevo artículo a partir del formulario new
*/

// incluir las clases necesarias
require_once 'class/articulo.class.php';
require_once 'class/tabla_articulos.class.php';

// incluir el modelo
require_once 'models/create.model.php';

// incluir la vista
require_once 'views/index.view.php';
?>