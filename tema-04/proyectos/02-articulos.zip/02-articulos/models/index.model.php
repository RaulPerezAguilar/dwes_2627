<?php

/*
    modelo: index.model.php
    descripción: Modelo principal del proyecto CRUD de artículos POO
*/

# Símbolo moneda local
setlocale(LC_MONETARY, 'es_ES.UTF-8');

// Crea una instancia de la tabla de artículos
$tabla_articulos = new Class_tabla_articulos();

// Obtener los datos de  los  artículos
$tabla_articulos->get_datos();

// Obtener el array de objetos de la  clase artículos
$articulos = $tabla_articulos->getArticulos();

// Obtener las categorías disponibles
$categorias = Class_tabla_articulos::getCategorias();

// Obtener las marcas disponibles
$marcas = Class_tabla_articulos::getMarcas();

?>