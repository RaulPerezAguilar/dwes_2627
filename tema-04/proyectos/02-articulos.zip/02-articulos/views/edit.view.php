<!DOCTYPE html>
<html lang="es">

<head>
    <!-- Cargar bootstrap -->
    <?php require_once 'views/layouts/head.layout.php'; ?>
    <title> Proyecto 4.2 - CRUD Gestión Artículos POO</title>
</head>

<body>

    <!-- capa principal -->
    <div class="container mt-3">

        <!-- cabecera del documento -->
        <?php require_once 'views/partials/header.partial.php'; ?>

        <!-- contenido principal -->
        <main>
            <!-- Formulario añadir nuevo libro -->
            <legend>Formulario Editar Artículo</legend>
            <form action="update.php?id=<?= $id ?>" method="POST">

                <!-- campo id -->
                <div class="mb-3">
                    <label for="id" class="form-label">ID:</label>
                    <input type="number" class="form-control" id="id" name="id" value="<?=  $articulo->getId() ?>" readonly>
                </div>

                <!-- campo descripción -->
                <div class="mb-3">
                    <label for="titulo" class="form-label">Descripción:</label>
                    <input type="text" class="form-control" id="titulo" name="descripcion" value="<?=  $articulo->getDescripcion() ?>" required>
                </div>

                <!-- campo modelo -->
                <div class="mb-3">
                    <label for="autor" class="form-label">Modelo:</label>
                    <input type="text" class="form-control" id="autor" name="modelo" value="<?=  $articulo->getModelo() ?>" required>
                </div>

                <!-- Select Dinámico Marcas -->
                <div class="mb-3">
                    <label for="marca" class="form-label">Marca:</label>
                    <select class="form-select" name="marca" id="marca" required>
                        <option selected disabled>Seleccione una Marca</option>
                        <!-- mostrar lista marcas -->
                        <?php foreach ($marcas as $indice => $marca): ?>
                            <option value="<?= $indice ?>" 
                            <?=  ($articulo->getMarca() == $indice)? 'selected' : null  ?>
                            >
                                <?= $marca ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                 <!-- campo unidades -->
                <div class="mb-3">
                    <label for="precio" class="form-label">Unidades:</label>
                    <input type="number" step="0.01" class="form-control" id="precio" name="unidades" value="<?=  $articulo->getUnidades() ?>" required>
                </div>

                <!-- campo precio -->
                <div class="mb-3">
                    <label for="precio" class="form-label">Precio:</label>
                    <input type="number" step="0.01" class="form-control" id="precio" name="precio" value="<?=  $articulo->getPrecio() ?>" required>
                </div>

                <!-- lista checbox dinámica de categorías -->
                <div class="mb-3">
                    <label class="form-label">Seleccione las categorías:</label>
                    <div class="form-control">
                        <?php foreach ($categorias as $indice=>$categoria): ?>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" name="categorias[]"
                                value="<?= $indice ?>" 
                                <?=  in_array($indice, $articulo->getCategorias())? 'checked': null ?>
                                >
                                <label class="form-check-label">
                                    <?= $categoria ?>
                                </label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- botones de acción -->
                <a class="btn btn-secondary" href="index.php" role="button"  
                onclick="return confirm('Confimar cancelación artículo')">Cancelar</a>
                <button type="reset" class="btn btn-secondary"  onclick="return confirm('Confimar reseteo artículo')">Limpiar</button>
                <button type="submit" class="btn btn-primary">Actualizar Artículo</button>
            </form>

            <br>
            <br>
            <br>
        </main>
        <!-- pie de página -->
        <?php require_once 'views/partials/footer.partial.php'; ?>

        <!-- javaScript bootstrap 5.3.8 -->
        <?php require_once 'views/layouts/js_bootstrap.layout.php'; ?>
</body>

</html>