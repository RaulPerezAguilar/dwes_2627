<?php 

/*
    controlador: delete.php
    descripción: Controlador que permite eliminar un artículo

    Parámetros GET:

    - id: artículo que voy a eliminar
*/

// incluir las clases necesarias
require_once 'class/articulo.class.php';
require_once 'class/tabla_articulos.class.php';

// incluir el modelo
require_once 'models/delete.model.php';

// incluir la vista
require_once 'views/index.view.php';

?>