<?php 

/*
    model: new.model.php
    descripción: genera los datos necesarios para el formulario de creación de un nuevo artículo
    Datos Necesarios:
        - array $categorias: lista de categorías disponibles para asignar al artículo
        - array $marcas: lista de marcas disponibles para asignar al artículo
*/

// incluir el array de  marcas
$marcas = Class_tabla_articulos::getMarcas();

// obtener array de categorías
$categorias = Class_tabla_articulos::getCategorias();



?>