<?php 

/*
    modelo: show.model.php
    descripción: carga los datos necesarios para mostrar en un formulario sin edición
    los detalles de un artículo

    Parámetros GET:

    - id: artículo a editar
*/

// Obtengo id  del artículo
$id = $_GET['id'] ?? null;

// Obtener el array de objetos de la clase artículos

// Creo un objeto de la clase  tabla_artículos
$tabla_articulos = new Class_tabla_articulos();

// Cargar  los  datos
$tabla_articulos->get_datos();

// Obtener los detalles del artículo mediante un objeto de la  clase articulo

// obtener  el índice del array en el que se  encuentra  el objeto de la clase artículo
$indice = $tabla_articulos->get_indice_from_id($id);

// Obtener el objeto de  la  clase artículo
$articulo = $tabla_articulos->get_articulo_from_indice($indice);

// Obtener array de  marcas
$marcas = Class_tabla_articulos::getMarcas();

// Obtener array de  categorias
$categorias = Class_tabla_articulos::getCategorias();



?>