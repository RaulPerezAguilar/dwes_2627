<?php

    /*
        Archivo: tabla_articulos.class.php
        Descripción: Clase Tabla_articulos array de objetos de la clase Articulo.   
        Características POO: Con encapsulamiento, constructor, getters y setters.
    */

    class Class_tabla_articulos
    {
        private $articulos;

        public function __construct()
        {
            $this->articulos = [];
        }

        /**
         * Get the value of articulos
         */
        public function getArticulos()
        {
            return $this->articulos;
        }

        /**
         * Set the value of articulos
         */
        public function setArticulos($articulos): self
        {
            $this->articulos = $articulos;

            return $this;
        }

        /*
            Método para obtener el array de marcas únicas de los artículos
            A cada artículo se le asignará una marca
            Descrición: Este método devuelve un array de marcas, y simula a la
            consulta SQL SELECT * FROM marcas.
        */

        static public function getMarcas() {

            return [
                "Samsung",
                "LG",
                "Sony",
                "Apple",
                "Huawei",
                "Xiaomi",
                "Nokia",
                "Motorola"
            ];

        }

        /*
            Método para obtener el array de categorías 
            A cada artículo se le asignarán varias categorías
            Descrición: Este método devuelve un array de categorías, y simula a la
            consulta SQL SELECT * FROM categorias.
        */
        static public function getCategorias() {

            return [
                "Electrónica",
                "Hogar",
                "Jardín",
                "Deportes",
                "Moda",
                "Salud",
                "Automoción",
                "Juguetes",
                "Libros",
                "Impresoras"
            ];

        }

        public function get_datos() {
           
            // crear artículos de ejemplo
            $articulo1 = new Class_articulo(
                1, 
                "Smartphone Samsung Galaxy S21", 
                "S21",
                 1,
                 [0, 2, 4],
                 12,
                799.99, 
            );

            // Añado nuevo objeto a la tabla de artículos
            $this->articulos[] = $articulo1;



            $articulo2 = new Class_articulo(
                2, 
                "Televisor LG OLED55CX6LA", 
                "OLED55CX6LA", 
                2,
                [0, 1, 3],
                5,
                1299.99
            );

            // Añado nuevo objeto a la tabla de artículos
            $this->articulos[] = $articulo2;

            $articulo3 = new Class_articulo(
                3, 
                "Portátil Apple MacBook Pro 16\"", 
                "MacBook Pro 16", 
                4,
                [0, 4],
                8,
                2399.99
            );

            // Añado nuevo objeto a la tabla de artículos
            $this->articulos[] = $articulo3;

            $articulo4 = new Class_articulo(
                4, 
                "Cámara Sony Alpha a7 III", 
                "Alpha a7 III", 
                3,
                [0, 5],
                10,
                1999.99
            );

            // Añado nuevo objeto a la tabla de artículos
            $this->articulos[] = $articulo4;

            $articulo5 = new Class_articulo(
                5, 
                "Smartphone Xiaomi Mi 11", 
                "Mi 11", 
                5,
                [0, 4],
                15,
                699.99
            );

            // Añado nuevo objeto a la tabla de artículos
            $this->articulos[] = $articulo5;

        }

    /*
        Función: categorias_indices_a_nombres($indices)
        Convertir array de índices de categorías a nombres de categorías
        Descripción: Este método recibe un array de índices de categorías y devuelve
        un array de nombres de categorías correspondientes.
        Parámetros:
            - $indices: array de índices de categorías
        Retorno:
            - array de nombres de categorías
    */
    static public function categorias_indices_a_nombres($indices) {
        // Obtener todas las categorías
        $todas_categorias = self::getCategorias();

        // Array para almacenar los nombres de las categorías
        $nombres_categorias = [];

        foreach ($indices as $indice) {
            
            $nombres_categorias[] = $todas_categorias[$indice];
            
        }

        return $nombres_categorias;
    }

    /*
        método: create()
        descripción: Añade un nuevo artículo 
        parámetros: 
        - objeto de la clase artículo
    */
    public function create(Class_articulo $articulo){
        $this->articulos[] = $articulo;
    }

    /*
        método: get_indice_from_id()
        descripción: obtiene  el índice del array en el que se encuentra un artículo
        a partir del id

        Parámetros:
        - id: id del  artículo

        Retorno:
        - índice: del  array
    */
    
    public function get_indice_from_id($id) {
        foreach($this->articulos as $indice => $articulo) {
            if ($articulo->getId() == $id) {
                return $indice;
            }
        }
        return  null;
    }

    /*
        método: get_articulo_fron_indice()
        descripcion: obtiene  un objeto de la clase  artículo a partir del indice del  array
        tabla artículos

        Parámetros:
        - índice: indice  en el  que se encuentra el artículo

        Retorna:
        - objeto de la clase artículo

    */
    public function get_articulo_from_indice($indice) {
        return  $this->articulos[$indice];
    }

    /*
        método: update()
        descripción: actualiza  los  detalles de un artículo en la  tabla a partir índice en el  
        que se encuentra dicho artículo

        Parámetros:
        - Objeto de la  clase artículo, con los  detalles del  artículo
        - indice del array en el que se encuentra dicho artículo
    */
    public function update(Class_articulo $articulo, $indice){
        // 
        $this->articulos[$indice]  = $articulo;
    }

    /*
        método: delete()
        descripción: elimino el artículo del array a partir del índice en le que se encuentra

        Parámetros:
        - indice: indice del array en el qu ese encuentra el artículo
    */
    public function  delete($indice){
        unset($this->articulos[$indice]);
        array_values($this->articulos);
    }
    }

?>