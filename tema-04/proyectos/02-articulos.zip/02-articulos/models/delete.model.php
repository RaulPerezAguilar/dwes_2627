<?php 

/*
    modelo: delete.model.php
    descripción: elimina un artículo de la tabla a partir de su id

    Parámetros GET:

    - id: artículo a eliminar
*/

// Obtengo id  del artículo
$id = $_GET['id'] ?? null;

// Creo un objeto de la clase  tabla_artículos
$tabla_articulos = new Class_tabla_articulos();

// Cargar  los  datos
$tabla_articulos->get_datos();

// obtener  el índice del array en el que se  encuentra  el objeto de la clase artículo
$indice = $tabla_articulos->get_indice_from_id($id);

// Eliminar el artículo del array mediante el método delete
$tabla_articulos->delete($indice);

// Obtener la tabla artículos
$articulos = $tabla_articulos->getArticulos();

// Obtener array de  marcas
$marcas = Class_tabla_articulos::getMarcas();

// Obtener array de  categorias
$categorias = Class_tabla_articulos::getCategorias();



?>