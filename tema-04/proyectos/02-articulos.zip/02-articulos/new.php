<?php

/*
    controlador: new.php
    descripción: Muestra el formulario para crear un nuevo artículo
*/

// incluir las clases necesarias
require_once 'class/articulo.class.php';
require_once 'class/tabla_articulos.class.php';

// incluir el modelo
require_once 'models/new.model.php';

// incluir la vista
require_once 'views/new.view.php';
?>