<?php

/*
    controlador: update.php
    descripción: Actualiza los detalles de un artículo a partir del formulario editable
*/

// incluir las clases necesarias
require_once 'class/articulo.class.php';
require_once 'class/tabla_articulos.class.php';

// incluir el modelo
require_once 'models/update.model.php';

// incluir la vista
require_once 'views/index.view.php';
?>