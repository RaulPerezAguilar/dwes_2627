<?php 

/*
    controlador: edit.php
    descripción: Controlador que permite mostrar en un formulario editable
    los detalles de un artículo

    Parámetros GET:

    - id: artículo que voy a editar
*/

// incluir las clases necesarias
require_once 'class/articulo.class.php';
require_once 'class/tabla_articulos.class.php';

// incluir el modelo
require_once 'models/edit.model.php';

// incluir la vista
require_once 'views/edit.view.php';

?>