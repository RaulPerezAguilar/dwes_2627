<?php

/*
    modelo: update.model.php
    descripción: obtener los detalles  del artículo editado
*/

// Cargo el id del artículo
$id_editar = $_GET['id'] ?? null;

// Cargar los detalles del formulario

$id = $_POST['id'] ?? null;
$descripcion = $_POST['descripcion'] ?? null;
$modelo = $_POST['modelo'] ?? null;
$marca = (int) $_POST['marca']?? null;
$categorias = $_POST['categorias'] ?? null;
$unidades = $_POST['unidades']?? null;
$precio = $_POST['precio']?? null;

// Validación


// Creo un objeto de la clase artículos  a partir de los detalles del formulario
$articulo = new Class_articulo(
    $id,
    $descripcion,
    $modelo,
    $marca,
    $categorias,
    $unidades,
    $precio
);

// Crear un objeto o instancia de la  clase tabla_articulos
$tabla_articulos = new Class_tabla_articulos();

// Cargar los datos
$tabla_articulos->get_datos();

// Obtener el índice de  la tabla artículos de dicho artículo
$indice =$tabla_articulos->get_indice_from_id($id_editar);

// Actualizo la tabla de  artículos
$tabla_articulos->update($articulo, $indice);

// Obtener array de objetos de la clase artículos
$articulos = $tabla_articulos->getArticulos();

// obtener array marcas
$marcas = Class_tabla_articulos::getMarcas();
// cargar array de categorias
$categorias = Class_tabla_articulos::getCategorias();




