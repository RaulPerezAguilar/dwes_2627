<header class="pb-3 mb-4 border-bottom">
    <i class="bi bi-stack"></i>
    <span class="fs-6">Proyecto 4.2 - Panel Control Artículos POO</span>
</header>