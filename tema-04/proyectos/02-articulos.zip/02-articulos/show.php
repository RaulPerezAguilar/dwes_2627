<?php 

/*
    controlador: show.php
    descripción: Controlador que permite mostrar los detalles de un artículo

    Parámetros GET:

    - id: artículo que voy a mostrar
*/

// incluir las clases necesarias
require_once 'class/articulo.class.php';
require_once 'class/tabla_articulos.class.php';

// incluir el modelo
require_once 'models/show.model.php';

// incluir la vista
require_once 'views/show.view.php';

?>